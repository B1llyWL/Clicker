import 'dart:math';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';


void main() {
 

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Clicker App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const ImageSwitcher(),
    );
  }
}

class ImageSwitcher extends StatefulWidget {
  const ImageSwitcher({super.key});

  @override
  ImageSwitcherState createState() => ImageSwitcherState();
}

class ImageSwitcherState extends State<ImageSwitcher> {
  final List<String> sounds = [
    'assets/sound1.mp3',
    'assets/sound2.mp3',
    'assets/sound3.mp3',
  ];

  String currentImage = 'assets/image1.png';
  final AudioPlayer audioPlayer = AudioPlayer();
  int clickCount = 0;



  void _onImageTap() {
    if (currentImage == 'assets/image1.png') {
      setState(() {
        currentImage = 'assets/image2.jpg'; // Change image
      });
    } else {
      setState(() {
        clickCount++; // Increase click count
      });
      _playRandomSound(); // Play a random sound
    }
  }

 Future<void> _playRandomSound() async {
  final randomIndex = Random().nextInt(sounds.length);
  try {
    await audioPlayer.play(sounds[randomIndex]); // Play a random sound
  } catch (e) {
    debugPrint("Error playing sound: $e"); // Log the error if sound playback fails
  }
}


  @override
  void dispose() {
    audioPlayer.dispose(); // Release audio player resources
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: _onImageTap,
              child: Image.asset(
                currentImage,
                width: currentImage == 'assets/image2.jpg' ? 450 : null,
                height: currentImage == 'assets/image2.jpg' ? 450 : null,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Количество кликов: $clickCount',
              style: const TextStyle(fontSize: 24),
            ),
          ],
        ),
      ),
    );
  }
}
